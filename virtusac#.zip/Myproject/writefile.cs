// using System;

// //We need to include this namespace for file handling.
// using System.IO;

// namespace ConsoleApplication1
// {
//     class Program
//     {
//         static void Main()
//         {
//             string s;

//             Console.WriteLine("Enter text to Write into File : ");
//             s = Console.ReadLine();

//             File.WriteAllText("ABC.TXT",s);
//             Console.WriteLine("\nFile Creation Done");
//         }
//     }
// }
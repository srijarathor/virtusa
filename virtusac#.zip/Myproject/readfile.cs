// using System;

// //We need to include this namespace for file handling.
// using System.IO;

// namespace ConsoleApplication1
// {
//     class Program
//     {
//         static void Main()
//         {
//             string s;

//             s =File.ReadAllText("ABC.TXT");

//             Console.WriteLine("Content of file :\n"+s);
//         }
//     }
// }